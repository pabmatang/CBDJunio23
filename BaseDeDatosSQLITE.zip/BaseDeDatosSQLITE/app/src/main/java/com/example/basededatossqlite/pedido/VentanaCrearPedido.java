package com.example.basededatossqlite.pedido;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import com.example.basededatossqlite.producto.VentanaCrearProducto;

import androidx.appcompat.app.AppCompatActivity;

import com.example.basededatossqlite.R;
import com.example.basededatossqlite.SQLite;
import com.example.basededatossqlite.producto.VentanaCrearProducto;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class VentanaCrearPedido extends AppCompatActivity {

    EditText txtUnidades;
   // EditText txtCodigo;
    EditText txtNumPedido;
    EditText txtDate;
    EditText txtDescripcion;
    EditText txtPrecio;
    EditText txtBuscarPor;
    //Spinner spBuscarPor;
    Spinner spEnumProducto;
    Spinner spListaProductos;
   // TableLayout tlEstadisticas;
    //TableLayout tlPedidos;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //super.onCreate(savedInstanceState);
        //setContentView(R.layout.portada);
        View vistaCrearPedido = LayoutInflater.from(this).inflate(R.layout.crearpedido,null,false);
        vistaCrearPedido(vistaCrearPedido);
        getSupportActionBar().setTitle("Crear Pedido");
    }

    public void vistaCrearPedido(View view){
        SQLite con3 = new SQLite(this);
        setContentView(R.layout.crearpedido);
        //txtNumPedido = findViewById(R.id.numPedido);

        txtPrecio = findViewById(R.id.precio2);
        // Obtener la fecha actual utilizando Calendar
        Calendar calendar = Calendar.getInstance();
        Date date = calendar.getTime();

        // Formatear la fecha en un formato deseado
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        String fechaActual = dateFormat.format(date);

        txtDate = findViewById(R.id.fecha);
        txtDate.setText(fechaActual);
        txtDate.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }
            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }
            @Override
            public void afterTextChanged(Editable editable) {
                String fechaIngresada = txtDate.getText().toString();
                boolean formatoValido = validarFormatoFecha(fechaIngresada);
                if(formatoValido){
                    txtDate.setError(null);
                }
                else {
                    txtDate.setError("Formato de fecha inválido");
                }

            }
        });



        txtUnidades = findViewById(R.id.unidades2);
        spEnumProducto = findViewById(R.id.spinner);
        List<String> tiposdeproducto = Arrays.asList("AGUA","REFRESCOS","BEBIDAS_ALCOHOLICAS","HIGIENE","FRUTOS_SECOS","CONGELADOS","FRUTA","VERDURA","LACTEOS","CARNES","PESCADOS","HUEVOS","DULCES");
        ArrayAdapter<String> adaptador = new ArrayAdapter(this, android.R.layout.simple_spinner_item, tiposdeproducto);
        spEnumProducto.setAdapter(adaptador);
        String sql3 = String.format ("select descripcion from productos");
        SQLiteDatabase baseDatos4 = con3.getWritableDatabase();
        Cursor fila5 = baseDatos4.rawQuery(sql3, null);
        spListaProductos = findViewById(R.id.spinnerProducto);
        StringBuilder stringBuilder = new StringBuilder();
        if (fila5 != null && fila5.moveToFirst()) {
            int columnCount = fila5.getColumnCount();
            do {
                for (int i = 0; i < columnCount; i++) {
                    String valor = fila5.getString(i);
                    stringBuilder.append(valor).append(",");
                }
            } while (fila5.moveToNext());
        }
        String listaP = stringBuilder.toString();
        listaP = listaP+",Nuevo";
        List<String> listaProductosExistentes = Arrays.asList(listaP.split(","));
        //Toast.makeText(this, ""+fila5.toString(), Toast.LENGTH_LONG).show();
        //listaProductosExistentes.add("Nuevo");
        ArrayAdapter<String> adaptador2 = new ArrayAdapter(this, android.R.layout.simple_spinner_item, listaProductosExistentes);
        spListaProductos.setAdapter(adaptador2);
        txtDescripcion = findViewById(R.id.descripcion2);
        /*if (!spListaProductos.getSelectedItem().toString().equals("Nuevo")) {
            txtDescripcion.setVisibility(View.GONE);
            view.invalidate();
        } else {
            txtDescripcion.setVisibility(View.VISIBLE);
            Toast.makeText(this, ""+spListaProductos.getSelectedItem().toString(), Toast.LENGTH_LONG).show();
        }*/
        txtDescripcion.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }
            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }
            @Override
            public void afterTextChanged(Editable editable) {
                if(spListaProductos.getSelectedItem().toString().equals("Nuevo")){
                    txtDescripcion.setError("Introducir descripcion producto nuevo");
                }
                else {
                    txtDate.setError("null");
                }

            }
        });

    }

    public void vistaInsertarPedido(View view) throws ParseException {
        SQLite con = new SQLite(this);
        SQLiteDatabase baseDatos = con.getWritableDatabase();
        String tipoProducto = spEnumProducto.getSelectedItem().toString();
        String listaProductos = spListaProductos.getSelectedItem().toString();
        String descripcion = "";
        if(listaProductos.equals("Nuevo")) {
            descripcion = txtDescripcion.getText().toString();
        }else{
            descripcion = listaProductos;
        }
        String unidades = txtUnidades.getText().toString();
        //String numPedido = txtNumPedido.getText().toString();
        String precio = txtPrecio.getText().toString();
        String fecha = txtDate.getText().toString();

        String sql = String.format ("select idProducto from productos where descripcion LIKE '%%%s%%'",descripcion);
        SQLite con1 = new SQLite(this);
        SQLiteDatabase baseDatos2 = con1.getWritableDatabase();
        Cursor fila3 = baseDatos2.rawQuery(sql, null);
        Cursor fila4 = baseDatos2.rawQuery(sql, null);
        fila3.moveToPosition(fila3.getPosition()+1);
        String idProducto="";
        idProducto=VentanaCrearProducto.vistaInsertarProductodesdePedido(descripcion,unidades,tipoProducto,precio,this);
        //if (fila3.getCount()==0) {
        //Toast.makeText(this, "idProducto"+idProducto, Toast.LENGTH_LONG).show();


        /*
        if (fila3.getCount()==0) {

                Toast.makeText(this, "El producto no existe en la base de datos", Toast.LENGTH_LONG).show();
                ContentValues registro = new ContentValues();
                registro.put("unidades", unidades);
                registro.put("descripcion", descripcion);
                registro.put("precio", precio);
                registro.put("tipoProducto", tipoProducto);
                baseDatos.insert("productos", null, registro);
                Toast.makeText(this, "Se ha creado el producto " + descripcion, Toast.LENGTH_LONG).show();
                String sql2 = String.format("select idProducto from productos where descripcion LIKE '%%%s%%'", descripcion);
                SQLite con2 = new SQLite(this);
                SQLiteDatabase baseDatos3 = con2.getWritableDatabase();
                fila4 = baseDatos3.rawQuery(sql2, null);
                fila4.moveToPosition(fila4.getPosition() + 1);

                idProducto = fila4.getString(0);

            } else {

                    idProducto = fila3.getString(0);

                    String sql2 = String.format("select unidades from productos where descripcion LIKE '%%%s%%'", descripcion);
                    SQLite con2 = new SQLite(this);
                    SQLiteDatabase baseDatos3 = con2.getWritableDatabase();
                    fila4 = baseDatos3.rawQuery(sql2, null);
                    fila4.moveToPosition(fila4.getPosition() + 1);
                    unidades = fila4.getString(0);
                    ContentValues registro = new ContentValues();

                    registro.put("idProducto", idProducto);
                    registro.put("unidades", Integer.parseInt(unidades) + Integer.parseInt(txtUnidades.getText().toString()));
                    registro.put("descripcion", descripcion);
                    registro.put("precio", precio);
                    registro.put("tipoProducto", tipoProducto);

                    int cant = baseDatos.update("productos", registro, "idProducto=" + idProducto + "", null);

                    if (cant > 0) {
                        Toast.makeText(this, "Las unidades del productos se han añadido al stock", Toast.LENGTH_LONG).show();
                    } else {
                        Toast.makeText(this, "Las unidades del productos no se han añadido al stock", Toast.LENGTH_LONG).show();

                    }
                }
            //}*/


        if (descripcion.isEmpty() == false  && precio.isEmpty() == false && fecha.isEmpty() == false && unidades.isEmpty() == false) {


            //if(fecha.equals(fechaPedido) || fila5.getCount()<=0) {
                ContentValues registro = new ContentValues();
                registro.put("descripcion", descripcion);
                registro.put("numPedido", generarNumeroPedido(fecha));
                registro.put("importe", precio);
                registro.put("fecha", fecha);
                baseDatos.insert("pedidos", null, registro);
                txtDescripcion.setText("");
                //txtNumPedido.setText("");
                txtPrecio.setText("");
                txtDate.setText("");
                txtUnidades.setText("");
                Toast.makeText(this, "Se insertado el pedido "+generarNumeroPedido(fecha) +" exitosamente", Toast.LENGTH_LONG).show();
                ContentValues registro2 = new ContentValues();
                registro2.put("unidades", unidades);
                registro2.put("idProducto", idProducto);
                String sql2 = String.format("select idPedido from pedidos where fecha LIKE '%%%s%%' and descripcion LIKE '%%%s%%'",fecha,descripcion);
                SQLite con2 = new SQLite(this);
                SQLiteDatabase baseDatos3 = con2.getWritableDatabase();
                Cursor filaidPedido = baseDatos3.rawQuery(sql2, null);
                filaidPedido.moveToPosition(filaidPedido.getPosition() + 1);
                registro2.put("idPedido", filaidPedido.getString(0));
                baseDatos.insert("pedidosdeproductos", null, registro2);
                Toast.makeText(this, "Se insertado el pedido en la tabla pedisosdeprodcutos exitosamenteeeeee", Toast.LENGTH_LONG).show();

        } else{

            Toast.makeText(this, "Los campos requeridos deben tener texto", Toast.LENGTH_LONG).show();
        }
        baseDatos.close();

    }
    private boolean validarFormatoFecha(String fecha) {
        // Aquí puedes implementar tu lógica de validación de fecha utilizando expresiones regulares o cualquier otra técnica que desees.
        // Por ejemplo, puedes utilizar SimpleDateFormat para verificar si la fecha cumple con un determinado formato.
        // En este ejemplo, estamos verificando si la fecha tiene el formato "dd/MM/yyyy".
        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
            dateFormat.setLenient(false);
            dateFormat.parse(fecha);
            return true;
        } catch (ParseException e) {
            return false;
        }
    }

    public String generarNumeroPedido(String fecha) throws ParseException {
        // Obtener la fecha actual
        Integer contador = 1;


        // Formatear la fecha en el formato deseado (AAAAMMDD)
        //SimpleDateFormat formatoFecha = new SimpleDateFormat("yyyyMMdd");
        //String fechaFormateada = String.valueOf(formatoFecha.parse(fecha));
        SimpleDateFormat formatoFechaEntrada = new SimpleDateFormat("dd/MM/yyyy");
        SimpleDateFormat formatoFechaSalida = new SimpleDateFormat("yyyyMMdd");

        String numeroPedido = "0";
        try {
            //String fechaString = fecha;

            // Convertir la cadena de fecha en un objeto Date
            Date fechaPedido = formatoFechaEntrada.parse(fecha);

            // Formatear la fecha en el nuevo formato
            String fechaFormateada = formatoFechaSalida.format(fechaPedido);

            //System.out.println("Fecha formateada: " + fechaFormateada);

            // Generar el número de pedido combinando la fecha y el contador
            numeroPedido = fechaFormateada;

            // Incrementar el contador para el siguiente pedido
            /*String sql2 = String.format("select distinct idPedido from pedidos where fecha LIKE '%%%s%%'",fecha);
            SQLite con2 = new SQLite(this);
            SQLiteDatabase baseDatos3 = con2.getWritableDatabase();
            Cursor filaNumeroPedido = baseDatos3.rawQuery(sql2, null);
            filaNumeroPedido.moveToPosition(filaNumeroPedido.getPosition() + 1);
            contador=filaNumeroPedido.getCount();
            Toast.makeText(this, "contador"+contador, Toast.LENGTH_LONG).show();
            contador++;
            numeroPedido = fechaFormateada + "-" + String.format("%04d", contador);*/
        } catch (ParseException e) {
            e.printStackTrace();
        }

        return numeroPedido;
    }
}
