package com.example.basededatossqlite.producto;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.basededatossqlite.R;
import com.example.basededatossqlite.SQLite;

import java.util.Arrays;
import java.util.List;

public class VentanaCrearProducto extends AppCompatActivity {
    EditText txtCodigo;
    EditText txtUnidades;
    EditText txtDescripcion;
    EditText txtPrecio;
    EditText txtBuscarPor;
    TableLayout tlProductos;
    Spinner spBuscarPor;
    Spinner spEnumProducto;
    EditText txtTipoProducto;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //super.onCreate(savedInstanceState);
        //setContentView(R.layout.portada);
        View vistaCrearProducto = LayoutInflater.from(this).inflate(R.layout.crearproducto,null,false);
        vistaCrearProducto2(vistaCrearProducto);
        getSupportActionBar().setTitle("Crear Producto");
    }



    public void vistaCrearProducto2(View view) {
        setContentView(R.layout.crearproducto);
        txtUnidades = findViewById(R.id.unidades);
        txtDescripcion = findViewById(R.id.descripcion);
        txtPrecio = findViewById(R.id.precio);

        spEnumProducto = findViewById(R.id.spinner2);


        List<String> tiposdeproducto = Arrays.asList("AGUA", "REFRESCOS", "BEBIDAS_ALCOHOLICAS", "HIGIENE", "FRUTOS_SECOS", "CONGELADOS", "FRUTA", "VERDURA", "LACTEOS", "CARNES", "PESCADOS", "HUEVOS", "DULCES");
        ArrayAdapter<String> adaptador = new ArrayAdapter(this, android.R.layout.simple_spinner_item, tiposdeproducto);
        spEnumProducto.setAdapter(adaptador);

    }
    public void vistaInsertarProducto(View view){
            SQLite con = new SQLite(this);
            SQLiteDatabase baseDatos = con.getWritableDatabase();
            //String codigo = añadirCodigoProdcutoAleatoriamente().toString();
            String descripcion = txtDescripcion.getText().toString();
            String precio = txtPrecio.getText().toString();
            String unidades = txtUnidades.getText().toString();
            //spEnumProducto = findViewById(R.id.spinner2);

            String tipoProducto = spEnumProducto.getSelectedItem().toString();
            txtTipoProducto = findViewById(R.id.txtTipoProducto);
            //Cursor codigoMinActual = baseDatos.rawQuery("select count(codigo) from productos",null);
            //codigoMinActual.moveToPosition(codigoMinActual.getPosition()+1);
           // Integer codigoMinActual2=codigoMinActual.getInt(0);


        if (unidades.isEmpty() == false &&  descripcion.isEmpty() == false && precio.isEmpty() == false && tipoProducto.isEmpty() == false) {

                ContentValues registro = new ContentValues();
                registro.put("unidades", unidades);
                //registro.put("codigo", codigo);
                registro.put("descripcion", descripcion);
                registro.put("precio", precio);
                registro.put("tipoProducto", tipoProducto);
                baseDatos.insert("productos", null, registro);
                txtUnidades.setText("");
                txtDescripcion.setText("");
                txtPrecio.setText("");
                //txtTipoProducto.setText("");
                Toast.makeText(this, "Se insertado exitosamente", Toast.LENGTH_LONG).show();

        } else {
                Toast.makeText(this, "Los campos deben tener texto", Toast.LENGTH_LONG).show();
            }
            baseDatos.close();

    }
    public static String vistaInsertarProductodesdePedido(String descripcion, String unidades, String tipoProducto, String precio, Context context) {
        SQLite con = new SQLite(context);
        SQLiteDatabase baseDatos = con.getWritableDatabase();
        String sql = String.format("select idProducto from productos where descripcion LIKE '%%%s%%'", descripcion);
        SQLite con1 = new SQLite(context);
        SQLiteDatabase baseDatos2 = con1.getWritableDatabase();
        Cursor fila3 = baseDatos2.rawQuery(sql, null);
        Cursor fila4 = baseDatos2.rawQuery(sql, null);
        fila3.moveToPosition(fila3.getPosition() + 1);
        String idProducto = "";

        if (fila3.getCount() == 0) {

            Toast.makeText(context, "El producto no existe en la base de datos", Toast.LENGTH_LONG).show();
            ContentValues registro = new ContentValues();
            registro.put("unidades", unidades);
            registro.put("descripcion", descripcion);
            registro.put("precio", precio);
            registro.put("tipoProducto", tipoProducto);
            baseDatos.insert("productos", null, registro);
            Toast.makeText(context, "Se ha creado el producto " + descripcion, Toast.LENGTH_LONG).show();
            String sql2 = String.format("select idProducto from productos where descripcion LIKE '%%%s%%'", descripcion);
            SQLite con2 = new SQLite(context);
            SQLiteDatabase baseDatos3 = con2.getWritableDatabase();
            fila4 = baseDatos3.rawQuery(sql2, null);
            fila4.moveToPosition(fila4.getPosition() + 1);
            idProducto = fila4.getString(0);
            //}
        } else {
            //if (vacio) {
            //Toast.makeText(this, "se queda aqui en el else"+fechaPedido, Toast.LENGTH_LONG).show();
            idProducto = fila3.getString(0);
            String sql2 = String.format("select unidades from productos where descripcion LIKE '%%%s%%'", descripcion);
            SQLite con2 = new SQLite(context);
            SQLiteDatabase baseDatos3 = con2.getWritableDatabase();
            fila4 = baseDatos3.rawQuery(sql2, null);
            fila4.moveToPosition(fila4.getPosition() + 1);
            String unidadesPedido = fila4.getString(0);
            ContentValues registro = new ContentValues();

            registro.put("idProducto", idProducto);
            registro.put("unidades", Integer.parseInt(unidadesPedido) + Integer.parseInt(unidades));
            registro.put("descripcion", descripcion);
            registro.put("precio", precio);
            registro.put("tipoProducto", tipoProducto);

            int cant = baseDatos.update("productos", registro, "idProducto=" + idProducto + "", null);

            if (cant > 0) {
                Toast.makeText(context, "Las unidades del productos se han añadido al stock", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(context, "Las unidades del productos no se han añadido al stock", Toast.LENGTH_LONG).show();

            }
        }
    return idProducto;
    }


}
