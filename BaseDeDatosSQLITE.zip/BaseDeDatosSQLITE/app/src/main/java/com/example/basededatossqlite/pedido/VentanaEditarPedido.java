package com.example.basededatossqlite.pedido;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.basededatossqlite.R;
import com.example.basededatossqlite.SQLite;

import java.util.Arrays;
import java.util.List;

public class VentanaEditarPedido extends AppCompatActivity {

    EditText txtCodigo;
    EditText txtUnidades;
    EditText txtNumPedido;
    EditText txtDate;
    EditText txtDescripcion;
    EditText txtPrecio;
    EditText txtBuscarPor;
    TableLayout tlProductos;
    Spinner spBuscarPor;
    TableLayout tlEstadisticas;
    TableLayout tlPedidos;
    Spinner spEnumProducto;
    EditText txtTipoProducto;
    private String idPedido;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.portada);
        View vistaEditarPedido = LayoutInflater.from(this).inflate(R.layout.activity_main2,null,false);
        vistaEditarPedido(vistaEditarPedido);
        getSupportActionBar().setTitle("Editar Pedido");

    }

    public void vistaEditarPedido(View view){
        setContentView(R.layout.activity_main2);

        txtDescripcion = findViewById(R.id.descripcion3);
        txtNumPedido = findViewById(R.id.numPedido3);
        txtPrecio = findViewById(R.id.precio3);
        txtDate = findViewById(R.id.fecha2);
        tlPedidos = findViewById(R.id.tlPedidos);
        txtBuscarPor = findViewById(R.id.txtBuscarPor);
        spBuscarPor = findViewById(R.id.spBuscarPor);
        List<String> listaCampos = Arrays.asList("Seleccione","descripcion","fecha","numPedido");
        ArrayAdapter<String> adaptador = new ArrayAdapter(this, android.R.layout.simple_spinner_item, listaCampos);
        spBuscarPor.setAdapter(adaptador);
        llenarTabla2();

    }
    public void editar2(View view) {
        SQLite con = new SQLite(this);
        SQLiteDatabase baseDatos = con.getWritableDatabase();
        String numPedido = txtNumPedido.getText().toString();
        String descripcion = txtDescripcion.getText().toString();
        String fecha = txtDate.getText().toString();
        String precio = txtPrecio.getText().toString();
        /*String sql2 = String.format ("select idPedido from pedidos where numPedido=%s and descripcion LIKE '%%%s%%'", numPedido,descripcion);
        SQLite con2 = new SQLite(this);
        SQLiteDatabase baseDatos2 = con2.getWritableDatabase();
        Cursor fila4 = baseDatos2.rawQuery(sql2, null);
        fila4.moveToPosition(fila4.getPosition()+1);*/
        //String idPedido = fila4.getString(0);


        if (!descripcion.isEmpty() && !numPedido.isEmpty() && !precio.isEmpty()&& !fecha.isEmpty()) {
            ContentValues registro = new ContentValues();
            registro.put("numPedido", numPedido);
            registro.put("descripcion", descripcion);
            registro.put("importe", precio);
            registro.put("fecha", fecha);
            //registro.put("unidades", unidades);


            int cant = baseDatos.update("pedidos", registro, "idPedido="+idPedido+"",null);

            if (cant > 0) {
                Toast.makeText(this, "El registro se a editado exitosamente", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "El registro no fue encontrado"+ numPedido, Toast.LENGTH_LONG).show();
            }
        } else {
            Toast.makeText(this, "Los campos no deben estar vacios", Toast.LENGTH_LONG).show();
        }

        llenarTabla2();
    }


    public void eliminar2(View view) {
        SQLite con = new SQLite(this);
        SQLiteDatabase baseDatos = con.getWritableDatabase();
        String numPedido = txtNumPedido.getText().toString();
        if (numPedido.isEmpty() == false) {
            int cant = baseDatos.delete("pedidos", "numPedido="+numPedido+"", null);
            if (cant > 0) {
                Toast.makeText(this, "El pedido fue eliminado", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "El pedido no se encontro", Toast.LENGTH_LONG).show();
            }
            txtNumPedido.setText("");
            txtDescripcion.setText("");
            txtPrecio.setText("");
            txtDate.setText("");
        } else {
            Toast.makeText(this, "El campo numero de pedido debe tener texto", Toast.LENGTH_LONG).show();
        }
        vistaEditarPedido(view);
    }
    public void resetColorRegistros2(){

        for (int i=0;i<tlPedidos.getChildCount();i++){
            View registros = tlPedidos.getChildAt(i);
            registros.setBackgroundColor(Color.WHITE);
        }

    }

    public void clickBotonBuscar2(View view){
        llenarTabla2();

    }

    private void llenarTabla2() {
        tlPedidos.removeAllViews();
        SQLite con = new SQLite(this);
        SQLiteDatabase baseDatos = con.getWritableDatabase();
        String buscarPor = txtBuscarPor.getText().toString();

        String listaBuscarPor = spBuscarPor.getSelectedItem().toString();
        String sql = "";


        if (!buscarPor.isEmpty()) {
            if (listaBuscarPor == "descripcion") {
                sql = String.format("select numPedido,descripcion,importe,fecha from pedidos where descripcion LIKE '%%%s%%'", buscarPor);
            }else if (listaBuscarPor == "numPedido") {
                sql = String.format("select numPedido,descripcion,importe,fecha from pedidos where numPedido LIKE '%%%s%%'",buscarPor);
            }else if (listaBuscarPor == "fecha") {
                sql = String.format ("select numPedido,descripcion,importe,fecha from pedidos where fecha LIKE '%%%s%%'", buscarPor);


            } else {
                sql = "select numPedido,descripcion,importe,fecha from pedidos";
            }
        } else {
            sql = "select numPedido,descripcion,importe,fecha from pedidos";

        }
        //Toast.makeText(this, "sql : "+sql, Toast.LENGTH_SHORT).show();
        Cursor fila = baseDatos.rawQuery(sql, null);
        fila.moveToFirst();
        do {

            View registro = LayoutInflater.from(this).inflate(R.layout.item_table_layout_pn3, null, false);
            TextView tvnumPedido = registro.findViewById(R.id.tvnumPedido);
            TextView tvdescripcion = registro.findViewById(R.id.tvDescripcion2);
            TextView tvprecio = registro.findViewById(R.id.tvUnidades2);
            TextView tvfecha = registro.findViewById(R.id.tvFecha);
            tvnumPedido.setText(fila.getString(0));
            tvdescripcion.setText(fila.getString(1));
            tvprecio.setText(fila.getString(2));
            tvfecha.setText(fila.getString(3));
            tlPedidos.addView(registro);

        } while (fila.moveToNext());
    }
    public void clickRegistroProducto2(View view){
        resetColorRegistros2();
        view.setBackgroundColor(Color.GRAY);
        TableRow registro= (TableRow) view;

        TextView controlnumPedido= (TextView) registro.getChildAt(0);
        String numPedido=controlnumPedido.getText().toString();
        TextView controlDescripcion= (TextView) registro.getChildAt(1);
        String descripcion = controlDescripcion.getText().toString();
        SQLite con = new SQLite(this);
        SQLiteDatabase baseDatos = con.getWritableDatabase();
        String sql2 = String.format ("select idPedido from pedidos where numPedido LIKE '%%%s%%' and descripcion LIKE '%%%s%%'", numPedido,descripcion);
        SQLite con2 = new SQLite(this);
        SQLiteDatabase baseDatos2 = con2.getWritableDatabase();
        Cursor fila4 = baseDatos2.rawQuery(sql2, null);
        fila4.moveToPosition(fila4.getPosition()+1);
        idPedido = fila4.getString(0);


        if(!numPedido.isEmpty()) {
            String sql = String.format ("select numPedido,descripcion,importe,fecha from pedidos where idPedido=%s", idPedido);
            Cursor fila = baseDatos.rawQuery(sql, null);
            fila.moveToPosition(fila.getPosition()+1);

            txtNumPedido.setText(fila.getString(0));
            txtDescripcion.setText(fila.getString(1));
            txtDate.setText(fila.getString(3));
            txtPrecio.setText(fila.getString(2));

        } else {
            txtNumPedido.setText("");
            txtCodigo.setText("");
            txtDate.setText("");
            txtPrecio.setText("");
            Toast.makeText(this, "No se ha encontrado ningun registro", Toast.LENGTH_SHORT).show();
        }

    }
}
