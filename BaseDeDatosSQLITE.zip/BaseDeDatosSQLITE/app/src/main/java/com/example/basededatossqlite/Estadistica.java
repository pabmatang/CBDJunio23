package com.example.basededatossqlite;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Printer;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.PrintWriter;
import java.util.Arrays;
import java.util.List;

public class Estadistica extends AppCompatActivity {
    TableLayout tlEstadisticas;
    TableLayout tlNProducto;
    Spinner spListaPedidos;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
       //setContentView(R.layout.estadistica);
        View vistaEstadistica = LayoutInflater.from(this).inflate(R.layout.estadistica,null,false);
        vistaEstadistica(vistaEstadistica);
        getSupportActionBar().setTitle("Estadistica");
    }

    public void clickBotonBuscar2(View view){
        vistaEstadistica2();

    }

    private void vistaEstadistica2() {
        setContentView(R.layout.estadistica);
        tlNProducto = findViewById(R.id.tlNPedidos);
        tlEstadisticas = findViewById(R.id.tlEstadisticas);
        //tlNProducto = findViewById(R.id.tlNPedidos);
        SQLite con = new SQLite(this);
        SQLiteDatabase baseDatos = con.getWritableDatabase();
        View registro = LayoutInflater.from(this).inflate(R.layout.item_table_layout_pn2, null, false);
        TextView tvAVGPrecioProducto = registro.findViewById(R.id.tvAVGPro);
        TextView tvAVGProductosPorPrecio = registro.findViewById(R.id.tvMaxPro);
        TextView tvMaxImporte = registro.findViewById(R.id.tvMinPro);
        TextView tvMinImporte = registro.findViewById(R.id.tvAVGPe);
        TextView tvMaxUnidades = registro.findViewById(R.id.tvMaxPe);
        TextView tvMinUnidades = registro.findViewById(R.id.tvMinPe);
        String listaPedidos = spListaPedidos.getSelectedItem().toString();
        View registro2 = LayoutInflater.from(this).inflate(R.layout.item_table_layout_pn5, null, false);
        TextView tvnumPedidoElegido = registro2.findViewById(R.id.tvNumPedidoElegido);
        tvnumPedidoElegido.setText(spListaPedidos.getSelectedItem().toString());
        tlNProducto.addView(registro2);

        String sql = "";
        sql = String.format("select distinct descripcion from pedidos where numPedido LIKE '%%%s%%'", listaPedidos);
        Double suma_unidades_importe = 0.;
        Double n_productos= 0.;
        Double importe =0.;
        Double unidades_totales = 0.;
        Double suma_total= 0.;
        Integer n_productosporpedido;
        Cursor listaProductos = baseDatos.rawQuery(sql,null);
        //PrecioProducto.moveToFirst();
        StringBuilder stringBuilder = new StringBuilder();
        if (listaProductos != null && listaProductos.moveToFirst()) {
            int columnCount = listaProductos.getColumnCount();
            do {
                for (int i = 0; i < columnCount; i++) {
                    String valor = listaProductos.getString(i);
                    stringBuilder.append(valor).append(",");
                }
            } while (listaProductos.moveToNext());
        }
        String listaPro = stringBuilder.toString();
        List<String> listaProductosdeunpedido = Arrays.asList(listaPro.split(","));
        for(String s:listaProductosdeunpedido){
            sql = String.format("select precio from productos where descripcion LIKE '%%%s%%'", s);

            Cursor PrecioProducto = baseDatos.rawQuery(sql,null);
            PrecioProducto.moveToFirst();
            importe = Double.parseDouble(PrecioProducto.getString(0));
            sql = String.format("select unidades from productos where descripcion LIKE '%%%s%%'",s);

            Cursor unidadesProducto = baseDatos.rawQuery(sql,null);
            unidadesProducto.moveToFirst();
            unidades_totales += Double.parseDouble(unidadesProducto.getString(0));
            n_productos = Double.parseDouble(unidadesProducto.getString(0));
            suma_unidades_importe += importe*n_productos;
        }
        suma_total=suma_unidades_importe/unidades_totales;
        tvAVGPrecioProducto.setText(suma_total.toString());

        sql = String.format("select distinct descripcion from pedidos where numPedido LIKE '%%%s%%'", listaPedidos);
        Cursor descripciones = baseDatos.rawQuery(sql,null);
        descripciones.moveToFirst();
        n_productosporpedido = descripciones.getCount();
        tvAVGProductosPorPrecio.setText(n_productosporpedido.toString());

        sql = String.format("select max(importe) from pedidos where numPedido LIKE '%%%s%%'", listaPedidos);
        Cursor mayorImporte = baseDatos.rawQuery(sql,null);
        mayorImporte.moveToFirst();
        String n_maximporte = String.valueOf(mayorImporte.getString(0));
        tvMaxImporte.setText(n_maximporte);

        sql = String.format("select min(importe) from pedidos where numPedido LIKE '%%%s%%'", listaPedidos);
        Cursor menorImporte = baseDatos.rawQuery(sql,null);
        menorImporte.moveToFirst();
        String n_menorImporte = String.valueOf(menorImporte.getString(0));
        tvMinImporte.setText(n_menorImporte);
        Integer maxUnidades = 0;

        for(String s:listaProductosdeunpedido){
            sql = String.format("select max(unidades) from productos where descripcion LIKE '%%%s%%'", s);

            Cursor PrecioProducto = baseDatos.rawQuery(sql,null);
            PrecioProducto.moveToFirst();

            if(maxUnidades<Integer.parseInt(PrecioProducto.getString(0))){
                maxUnidades = Integer.parseInt(PrecioProducto.getString(0));
            }

        }

        //sql = String.format("select max(unidades) from pedidos where numPedido LIKE '%%%s%%'", listaPedidos);
        //Cursor mayorUnidades = baseDatos.rawQuery(sql,null);
        //mayorUnidades.moveToFirst();
        //String n_mayorUnidades = String.valueOf(mayorUnidades.getString(0));
        tvMaxUnidades.setText(maxUnidades.toString());
        Integer minUnidades= maxUnidades;
        for(String s:listaProductosdeunpedido){
            sql = String.format("select min(unidades) from productos where descripcion LIKE '%%%s%%'", s);

            Cursor PrecioProducto = baseDatos.rawQuery(sql,null);
            PrecioProducto.moveToFirst();

            if(minUnidades>Integer.parseInt(PrecioProducto.getString(0))){
                minUnidades = Integer.parseInt(PrecioProducto.getString(0));
            }

        }
       // sql = String.format("select min(unidades) from pedidos where numPedido LIKE '%%%s%%'", listaPedidos);
        //Cursor menorUnidades = baseDatos.rawQuery(sql,null);
        //menorUnidades.moveToFirst();
        //String n_menorUnidades = String.valueOf(menorUnidades.getString(0));
        tvMinUnidades.setText(minUnidades.toString());


        tlEstadisticas.addView(registro);

    }


    public void vistaEstadistica(View view){

        setContentView(R.layout.estadistica);

        tlEstadisticas = findViewById(R.id.tlEstadisticas);
        tlNProducto = findViewById(R.id.tlNPedidos);
        SQLite con = new SQLite(this);
        SQLiteDatabase baseDatos = con.getWritableDatabase();

        View registro = LayoutInflater.from(this).inflate(R.layout.item_table_layout_pn2, null, false);

        TextView tvAVGPro = registro.findViewById(R.id.tvAVGPro);
        TextView tvMaxPro = registro.findViewById(R.id.tvMaxPro);
        TextView tvMinPro = registro.findViewById(R.id.tvMinPro);
        TextView tvAVGPe = registro.findViewById(R.id.tvAVGPe);
        TextView tvMaxPe = registro.findViewById(R.id.tvMaxPe);
        TextView tvMinPe = registro.findViewById(R.id.tvMinPe);

        Cursor avgPro = baseDatos.rawQuery("select avg(precio) from productos", null);
        avgPro.moveToFirst();
        tvAVGPro.setText(avgPro.getString(0));
        Cursor maxPro = baseDatos.rawQuery("select max(precio) from productos", null);
        maxPro.moveToFirst();
        tvMaxPro.setText(maxPro.getString(0));
        Cursor minPro = baseDatos.rawQuery("select min(precio) from productos", null);
        minPro.moveToFirst();
        tvMinPro.setText(minPro.getString(0));
        Cursor avgPe = baseDatos.rawQuery("select avg(importe) from pedidos", null);
        avgPe.moveToFirst();
        tvAVGPe.setText(avgPe.getString(0));
        Cursor maxPe = baseDatos.rawQuery("select max(importe) from pedidos", null);
        maxPe.moveToFirst();
        tvMaxPe.setText(maxPe.getString(0));
        Cursor minPe = baseDatos.rawQuery("select min(importe) from pedidos", null);
        minPe.moveToFirst();
        tvMinPe.setText(minPe.getString(0));
        //tlEstadisticas.addView(registro);
        String sql3 = String.format ("select distinct numPedido from pedidos");
        SQLite con3 = new SQLite(this);
        SQLiteDatabase baseDatos4 = con3.getWritableDatabase();
        Cursor fila5 = baseDatos4.rawQuery(sql3, null);
        spListaPedidos = findViewById(R.id.spinnerPedidos);
        StringBuilder stringBuilder = new StringBuilder();
        if (fila5 != null && fila5.moveToFirst()) {
            int columnCount = fila5.getColumnCount();
            do {
                for (int i = 0; i < columnCount; i++) {
                    String valor = fila5.getString(i);
                    stringBuilder.append(valor).append(",");
                }
            } while (fila5.moveToNext());
        }
        String listaP = stringBuilder.toString();
        List<String> listaPedidos = Arrays.asList(listaP.split(","));
        ArrayAdapter<String> adaptador = new ArrayAdapter(this, android.R.layout.simple_spinner_item, listaPedidos);
        spListaPedidos.setAdapter(adaptador);

    }


}
