package com.example.basededatossqlite;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


public class SQLite extends SQLiteOpenHelper {


    public static final int DATABASE_VERSION = 1;
    public static final String DATABASE_NAME = "StockDatabase.db";

    public SQLite(Context context) {

        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

   /*public SQLite(Context context, String DATABASE_NAME , int DATABASE_VERSION) {
        super(context,
                DATABASE_NAME,null,
                DATABASE_VERSION);
    }*/


    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table productos (idProducto integer primary key autoincrement,descripcion text,precio real,tipoProducto text,unidades int)");
        db.execSQL("create table pedidos (idPedido integer primary key autoincrement,numPedido int,descripcion text ,fecha date ,importe real)");
        db.execSQL("create table pedidosdeproductos (id integer primary key,idPedido int,idProducto int,unidades int,foreign key (idPedido) references pedidos(idPedido),foreign key (idProducto) references productos(idProducto))");

    }

    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        //db.execSQL(SQL_DELETE_ENTRIES);
        //onCreate(db);
    }
}

