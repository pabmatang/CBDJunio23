package com.example.basededatossqlite.producto;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.basededatossqlite.R;
import com.example.basededatossqlite.SQLite;

import java.util.Arrays;
import java.util.List;

public class VentanaEditarProducto extends AppCompatActivity {
    VentanaCrearProducto producto;
    EditText txtUnidades;
    EditText txtDescripcion;
    EditText txtPrecio;
    EditText txtBuscarPor;
    TableLayout tlProductos;
    Spinner spBuscarPor;
    Spinner spEnumProducto;
    EditText txtTipoProducto;
    private String idProducto;


    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //super.onCreate(savedInstanceState);
        //setContentView(R.layout.portada);
        View vistaEditarProducto = LayoutInflater.from(this).inflate(R.layout.activity_main,null,false);
        vistaEditar(vistaEditarProducto);
        getSupportActionBar().setTitle("Editar Producto");

    }


    public void vistaEditar(View view){
        setContentView(R.layout.activity_main);

        txtUnidades = findViewById(R.id.txtUnidades);
        txtDescripcion = findViewById(R.id.txtDescripcion);
        txtPrecio = findViewById(R.id.txtPrecio);
        tlProductos = findViewById(R.id.tlProductos);
        txtBuscarPor = findViewById(R.id.txtBuscarPor);
        spBuscarPor = findViewById(R.id.spBuscarPor);
        List<String> listaCampos = Arrays.asList("Seleccione el campo a buscar", "Unidades", "Descripcion", "Precio");
        ArrayAdapter<String> adaptador = new ArrayAdapter(this, android.R.layout.simple_spinner_item, listaCampos);
        spBuscarPor.setAdapter(adaptador);
        llenarTabla();

    }
    public void editar(View view) {
        SQLite con = new SQLite(this);
        SQLiteDatabase baseDatos = con.getWritableDatabase();
        //String codigo = txtCodigo.getText().toString();
        String descripcion = txtDescripcion.getText().toString();
        String precio = txtPrecio.getText().toString();
        String tipoProducto = txtTipoProducto.getText().toString();
        String unidades = txtUnidades.getText().toString();
        //String sql = String.format ("select codigo from productos where unidades=%s", unidades);
        String sql = String.format ("select idProducto from productos where descripcion LIKE '%%%s%%'", descripcion);
        SQLite con1 = new SQLite(this);
        SQLiteDatabase baseDatos2 = con1.getWritableDatabase();
        Cursor fila3 = baseDatos2.rawQuery(sql, null);
        Cursor fila4 = baseDatos2.rawQuery(sql, null);
        fila3.moveToPosition(fila3.getPosition()+1);
        //String idProducto = "";

        if (fila3.getCount()==0){
            /*String sql2 = String.format ("select idProducto from productos where descripcion LIKE '%%%s%%'", descripcion);
            SQLite con2 = new SQLite(this);
            SQLiteDatabase baseDatos3 = con2.getWritableDatabase();
            fila4 = baseDatos3.rawQuery(sql2, null);
            fila4.moveToPosition(fila4.getPosition()+1);*/
            //idProducto =fila4.getString(0);
        }else{
            idProducto=fila3.getString(0);
        }


        if (!unidades.isEmpty() && !descripcion.isEmpty() && !precio.isEmpty()) {
            //String codigo=fila3.getString(0);
            ContentValues registro = new ContentValues();
            registro.put("idProducto", idProducto);
            registro.put("unidades", unidades);
            registro.put("descripcion", descripcion);
            registro.put("precio", precio);
            registro.put("tipoProducto", tipoProducto);
            //Toast.makeText(this, "unidades="+unidades, Toast.LENGTH_LONG).show();


            int cant = baseDatos.update("productos", registro, "idProducto="+idProducto+"",null);

            if (cant > 0) {
                Toast.makeText(this, "El registro se a editado exitosamente", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "El registro no fue encontrado", Toast.LENGTH_LONG).show();
            }
        } else {
            Toast.makeText(this, "Los campos no deben estar vacios", Toast.LENGTH_LONG).show();
        }

        llenarTabla();
    }


    public void llenarTabla() {

        tlProductos.removeAllViews();
        SQLite con = new SQLite(this);
        SQLiteDatabase baseDatos = con.getWritableDatabase();
        String buscarPor = txtBuscarPor.getText().toString();
        String listaBuscarPor = spBuscarPor.getSelectedItem().toString();
        String sql = "";


        if (!buscarPor.isEmpty()) {
            if (listaBuscarPor == "Unidades") {
                sql = String.format ("select unidades,descripcion,precio,tipoProducto from productos where unidades=%s", buscarPor);
            } else if (listaBuscarPor == "Descripcion") {//DUDA AQUI
                //sql = String.format ("descripcion LIKE %%%s%%",buscarPor);

                //sql = String.format ("select codigo,descripcion,precio,tipoProducto from productos where descripcion LIKE "+"%"+buscarPor+"%");
                //Toast.makeText(this, sql+"    sale esto", Toast.LENGTH_SHORT).show();
                sql = String.format ("select unidades,descripcion,precio,tipoProducto from productos where descripcion LIKE '%%%s%%'",buscarPor);

                //sql = String.format ("select codigo,descripcion,precio,tipoProducto from productos where descripcion LIKE %s%",buscarPor);
            } else if (listaBuscarPor == "Precio") {
                sql = String.format ("select unidades,descripcion,precio,tipoProducto from productos where precio=%s", buscarPor);
            } else if (listaBuscarPor == "TipoProducto") {
                sql = String.format ("select unidades,descripcion,precio,tipoProducto from productos where tipoProducto LIKE '%%%s%%'", buscarPor);
            } else {
                sql = "select unidades,descripcion,precio,tipoProducto from productos";
            }
        } else {
            sql = "select unidades,descripcion,precio,tipoProducto from productos";

        }
        Cursor fila = baseDatos.rawQuery(sql , null);
        fila.moveToFirst();
        do {

            View registro = LayoutInflater.from(this).inflate(R.layout.item_table_layout_pn, null, false);
            TextView tvUnidades = registro.findViewById(R.id.tvDescripcion2);
            TextView tvDescripcion = registro.findViewById(R.id.tvNumPedidoElegido);
            TextView tvPrecio = registro.findViewById(R.id.tvPrecio);
            TextView tvTipoProducto = registro.findViewById(R.id.tvTipoProducto);
            //if(fila.getString(0).length()>0) {
            tvUnidades.setText(fila.getString(0));
            tvDescripcion.setText(fila.getString(1));
            tvPrecio.setText(fila.getString(2));
            tvTipoProducto.setText(fila.getString(3));
            tlProductos.addView(registro);
            //}

        } while (fila.moveToNext());

    }



    public void clickRegistroProducto(View view){
        resetColorRegistros();
        view.setBackgroundColor(Color.GRAY);
        TableRow registro= (TableRow) view;
        txtTipoProducto = findViewById(R.id.txtTipoProducto);
        txtUnidades=findViewById(R.id.txtUnidades);
        //txtDescripcion=findViewById(R.id.txtDescripcion);
        TextView controlCodigo= (TextView) registro.getChildAt(1);
        String descripcion=controlCodigo.getText().toString();
        String sql = String.format ("select idProducto from productos where descripcion LIKE '%%%s%%'", descripcion);
        SQLite con = new SQLite(this);
        SQLiteDatabase baseDatos = con.getWritableDatabase();
        Cursor fila = baseDatos.rawQuery(sql, null);
        fila.moveToPosition(fila.getPosition()+1);
        idProducto=fila.getString(0);
        //Toast.makeText(this, "primero:"+codigo, Toast.LENGTH_SHORT).show();


        if(!descripcion.isEmpty()) {
            //String sql2 = String.format ("select unidades,descripcion,precio,tipoProducto from productos where codigo=%s", codigo);
            String sql2 = String.format ("select unidades,descripcion,precio,tipoProducto from productos where descripcion LIKE '%%%s%%'", descripcion);

            Cursor fila2 = baseDatos.rawQuery(sql2, null);

            fila2.moveToPosition(fila2.getPosition()+1);


            txtUnidades.setText(fila2.getString(0));
            txtDescripcion.setText(fila2.getString(1));
            txtPrecio.setText(fila2.getString(2));
            txtTipoProducto.setText(fila2.getString(3));

        } else {
            txtUnidades.setText("");
            txtDescripcion.setText("");
            txtPrecio.setText("");
            txtTipoProducto.setText("");
            Toast.makeText(this, "No se ha encontrado ningun registro", Toast.LENGTH_SHORT).show();
        }

    }

    public void resetColorRegistros(){

        for (int i=0;i<tlProductos.getChildCount();i++){
            View registros = tlProductos.getChildAt(i);
            registros.setBackgroundColor(Color.WHITE);
        }

    }
    public void clickBotonBuscar(View view){
        llenarTabla();

    }

    public void eliminar(View view) {
        SQLite con = new SQLite(this);
        SQLiteDatabase baseDatos = con.getWritableDatabase();
        String sql = String.format("select codigo from productos where unidades=%s", txtUnidades.getText().toString());
        SQLite con1 = new SQLite(this);
        SQLiteDatabase baseDatos2 = con1.getWritableDatabase();
        Cursor fila3 = baseDatos2.rawQuery(sql, null);
        fila3.moveToPosition(fila3.getPosition() + 1);
        String codigo = fila3.getString(0);
        //String codigo = txtCodigo.getText().toString();
        if (codigo.isEmpty() == false) {
            int cant = baseDatos.delete("productos", "codigo=" + codigo + "", null);
            if (cant > 0) {
                Toast.makeText(this, "El producto fue eliminado", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "El producto no se encontro", Toast.LENGTH_LONG).show();
            }
            txtUnidades.setText("");
            txtDescripcion.setText("");
            txtPrecio.setText("");
        } else {
            Toast.makeText(this, "El campo codigo debe tener texto", Toast.LENGTH_LONG).show();
        }
        vistaEditar(view);
    }


}
