package com.example.basededatossqlite;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TableLayout;


import androidx.appcompat.app.AppCompatActivity;

import com.example.basededatossqlite.pedido.VentanaCrearPedido;
import com.example.basededatossqlite.pedido.VentanaEditarPedido;
import com.example.basededatossqlite.producto.VentanaCrearProducto;
import com.example.basededatossqlite.producto.VentanaEditarProducto;

public class MainActivity extends AppCompatActivity {

    EditText txtCodigo;
    EditText txtUnidades;
    EditText txtNumPedido;
    EditText txtDate;
    EditText txtDescripcion;
    EditText txtPrecio;
    EditText txtBuscarPor;
    TableLayout tlProductos;
    Spinner spBuscarPor;
    TableLayout tlEstadisticas;
    TableLayout tlPedidos;
    Spinner spEnumProducto;
    EditText txtTipoProducto;



    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.portada);

        Button botonEstadistica = (Button) findViewById(R.id.Estadistica);
        //botonEstadistica.setOnClickListener(new Estadistica());
        botonEstadistica.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =  new Intent(MainActivity.this,Estadistica.class);
                startActivity(intent);
            }
        });

        Button botonCrearProducto = (Button) findViewById(R.id.CrearProducto);
        botonCrearProducto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =  new Intent(MainActivity.this, VentanaCrearProducto.class);
                startActivity(intent);
            }
        });

        Button botonEditarProducto = (Button) findViewById(R.id.EditarProducto);
        botonEditarProducto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =  new Intent(MainActivity.this, VentanaEditarProducto.class);
                startActivity(intent);
            }
        });

        Button botonCrearPedido = (Button) findViewById(R.id.crearPedido);
        botonCrearPedido.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =  new Intent(MainActivity.this, VentanaCrearPedido.class);
                startActivity(intent);
            }
        });
        Button botonEditarPedido = (Button) findViewById(R.id.editarPedido);
        botonEditarPedido.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =  new Intent(MainActivity.this, VentanaEditarPedido.class);
                startActivity(intent);
            }
        });



    }

    /*

    public void vistaEditar(View view){
        setContentView(R.layout.activity_main);

        txtUnidades = findViewById(R.id.txtUnidades);
        txtDescripcion = findViewById(R.id.txtDescripcion);
        txtPrecio = findViewById(R.id.txtPrecio);
        tlProductos = findViewById(R.id.tlProductos);
        txtBuscarPor = findViewById(R.id.txtBuscarPor);
        spBuscarPor = findViewById(R.id.spBuscarPor);
        List<String> listaCampos = Arrays.asList("SelecScione el campo a buscar", "Unidades", "Descripcion", "Precio","Tipo de Producto");
        ArrayAdapter<String> adaptador = new ArrayAdapter(this, android.R.layout.simple_spinner_item, listaCampos);
        spBuscarPor.setAdapter(adaptador);
        llenarTabla();

    }

    public void vistaCrearProducto(View view) {
        setContentView(R.layout.crearproducto);
        //txtCodigo = findViewById(R.id.codigo);
        txtUnidades = findViewById(R.id.unidades);
        txtDescripcion = findViewById(R.id.descripcion);
        txtPrecio = findViewById(R.id.precio);

        spEnumProducto = findViewById(R.id.spinner2);


        List<String> tiposdeproducto = Arrays.asList("AGUA","REFRESCOS","BEBIDAS_ALCOHOLICAS","HIGIENE","FRUTOS_SECOS","CONGELADOS","FRUTA","VERDURA","LACTEOS","CARNES","PESCADOS","HUEVOS","DULCES");
        ArrayAdapter<String> adaptador = new ArrayAdapter(this, android.R.layout.simple_spinner_item, tiposdeproducto);
        spEnumProducto.setAdapter(adaptador);


    }
    public void vistaInsertarProducto(View view){
            SQLite con = new SQLite(this);
            SQLiteDatabase baseDatos = con.getWritableDatabase();
            //String codigo = añadirCodigoProdcutoAleatoriamente().toString();
            String descripcion = txtDescripcion.getText().toString();
            String precio = txtPrecio.getText().toString();
            String unidades = txtUnidades.getText().toString();
            //spEnumProducto = findViewById(R.id.spinner2);

            String tipoProducto = spEnumProducto.getSelectedItem().toString();
            txtTipoProducto = findViewById(R.id.txtTipoProducto);
            //Cursor codigoMinActual = baseDatos.rawQuery("select count(codigo) from productos",null);
            //codigoMinActual.moveToPosition(codigoMinActual.getPosition()+1);
           // Integer codigoMinActual2=codigoMinActual.getInt(0);


        if (unidades.isEmpty() == false &&  descripcion.isEmpty() == false && precio.isEmpty() == false && tipoProducto.isEmpty() == false) {

            //if(Integer.parseInt(codigo)<=codigoMinActual2){unidades.isEmpty() == false
              //  Toast.makeText(this, "Elegir un codigo mayor, ese esta en uso", Toast.LENGTH_LONG).show();

            //}else{
            //Toast.makeText(this, "Sale estoo del codigooooo"+txtCodigo, Toast.LENGTH_LONG).show();
                ContentValues registro = new ContentValues();
                registro.put("unidades", unidades);
                //registro.put("codigo", codigo);
                registro.put("descripcion", descripcion);
                registro.put("precio", precio);
                registro.put("tipoProducto", tipoProducto);
                baseDatos.insert("productos", null, registro);
                txtUnidades.setText("");
                txtDescripcion.setText("");
                txtPrecio.setText("");
                //txtTipoProducto.setText("");
                Toast.makeText(this, "Se insertado exitosamente", Toast.LENGTH_LONG).show();

                //}

        } else {

                Toast.makeText(this, "Los campos deben tener texto", Toast.LENGTH_LONG).show();
            }
            baseDatos.close();



    }

    public void vistaVolver(View view){

        setContentView(R.layout.portada);
    }*/
    /*
    public void vistaCrearPedido(View view){
        setContentView(R.layout.crearpedido);
        //txtNumPedido = findViewById(R.id.numPedido);
        txtDescripcion = findViewById(R.id.descripcion2);
        txtPrecio = findViewById(R.id.precio2);
        txtDate = findViewById(R.id.fecha);
        txtUnidades = findViewById(R.id.unidades2);
        spEnumProducto = findViewById(R.id.spinner);
        List<String> tiposdeproducto = Arrays.asList("AGUA","REFRESCOS","BEBIDAS_ALCOHOLICAS","HIGIENE","FRUTOS_SECOS","CONGELADOS","FRUTA","VERDURA","LACTEOS","CARNES","PESCADOS","HUEVOS","DULCES");
        ArrayAdapter<String> adaptador = new ArrayAdapter(this, android.R.layout.simple_spinner_item, tiposdeproducto);
        spEnumProducto.setAdapter(adaptador);


    }

    public void vistaInsertarPedido(View view){
        SQLite con = new SQLite(this);
        SQLiteDatabase baseDatos = con.getWritableDatabase();
        String descripcion = txtDescripcion.getText().toString();
        String unidades = txtUnidades.getText().toString();
        //String numPedido = txtNumPedido.getText().toString();
        String precio = txtPrecio.getText().toString();
        String fecha = txtDate.getText().toString();
        String tipoProducto = spEnumProducto.getSelectedItem().toString();
        String sql = String.format ("select codigo from productos where descripcion LIKE '%%%s%%'",descripcion);
        SQLite con1 = new SQLite(this);
        SQLiteDatabase baseDatos2 = con1.getWritableDatabase();
        Cursor fila3 = baseDatos2.rawQuery(sql, null);
        Cursor fila4 = baseDatos2.rawQuery(sql, null);
        fila3.moveToPosition(fila3.getPosition()+1);
        String codigo="";

        if (fila3.getCount()==0){
            Toast.makeText(this, "El producto no existe en la base de datos", Toast.LENGTH_LONG).show();
            ContentValues registro = new ContentValues();
            registro.put("unidades", unidades);
            registro.put("descripcion", descripcion);
            registro.put("precio", precio);
            registro.put("tipoProducto", tipoProducto);
            baseDatos.insert("productos", null, registro);
            Toast.makeText(this, "Se ha creado el producto "+descripcion, Toast.LENGTH_LONG).show();
            String sql2 = String.format ("select codigo from productos where descripcion LIKE '%%%s%%'",descripcion);
            SQLite con2 = new SQLite(this);
            SQLiteDatabase baseDatos3 = con2.getWritableDatabase();
            fila4 = baseDatos3.rawQuery(sql2, null);
            fila4.moveToPosition(fila4.getPosition()+1);
            codigo =fila4.getString(0);
        }else {
            codigo = fila3.getString(0);
            String sql2 = String.format ("select unidades from productos where descripcion LIKE '%%%s%%'",descripcion);
            SQLite con2 = new SQLite(this);
            SQLiteDatabase baseDatos3 = con2.getWritableDatabase();
            fila4 = baseDatos3.rawQuery(sql2, null);
            fila4.moveToPosition(fila4.getPosition()+1);
            unidades =fila4.getString(0);
            ContentValues registro = new ContentValues();

            registro.put("codigo", codigo);
            registro.put("unidades", Integer.parseInt(unidades)+Integer.parseInt(txtUnidades.getText().toString()));
            registro.put("descripcion", descripcion);
            registro.put("precio", precio);
            registro.put("tipoProducto", tipoProducto);

            int cant = baseDatos.update("productos", registro, "codigo=" + codigo + "", null);

            if (cant > 0) {
                Toast.makeText(this, "Las unidades del productos se han añadido al stock", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "Las unidades del productos no se han añadido al stock", Toast.LENGTH_LONG).show();

            }
        }
        if (descripcion.isEmpty() == false  && precio.isEmpty() == false && fecha.isEmpty() == false && unidades.isEmpty() == false) {

            ContentValues registro = new ContentValues();
            registro.put("codigo", codigo);
            registro.put("unidades", unidades);
            //registro.put("numPedido", numPedido);
            registro.put("importe", precio);
            registro.put("fecha", fecha);
            baseDatos.insert("pedidos", null, registro);
            txtDescripcion.setText("");
            //txtNumPedido.setText("");
            txtPrecio.setText("");
            txtDate.setText("");
            txtUnidades.setText("");
            Toast.makeText(this, "Se insertado el pedido exitosamente", Toast.LENGTH_LONG).show();
            ContentValues registro2 = new ContentValues();
            registro2.put("codigo", codigo);
            String sql2 = String.format ("select numPedido from pedidos where codigo=%s", codigo);
            SQLite con2 = new SQLite(this);
            SQLiteDatabase baseDatos3 = con2.getWritableDatabase();
            fila4 = baseDatos3.rawQuery(sql2, null);
            fila4.moveToPosition(fila4.getPosition()+1);
            String numPedido =fila4.getString(0);
            registro2.put("numPedido", numPedido);
            baseDatos.insert("pedidosdeproductos", null, registro2);
            Toast.makeText(this, "Se insertado el pedido en la tabla pedisosdeprodcutos exitosamente", Toast.LENGTH_LONG).show();

        } else{

            Toast.makeText(this, "Los campos requeridos deben tener texto", Toast.LENGTH_LONG).show();
        }
        baseDatos.close();

    }

    */
    /*
    public void vistaEditarPedido(View view){
        setContentView(R.layout.activity_main2);

        txtDescripcion = findViewById(R.id.descripcion3);
        txtNumPedido = findViewById(R.id.numPedido2);
        txtPrecio = findViewById(R.id.precio3);
        txtDate = findViewById(R.id.fecha2);
        tlPedidos = findViewById(R.id.tlPedidos);
        txtBuscarPor = findViewById(R.id.txtBuscarPor);
        spBuscarPor = findViewById(R.id.spBuscarPor);
        List<String> listaCampos = Arrays.asList("Seleccione","descripcion","fecha");
        ArrayAdapter<String> adaptador = new ArrayAdapter(this, android.R.layout.simple_spinner_item, listaCampos);
        spBuscarPor.setAdapter(adaptador);
        llenarTabla2();

    }

    public void vistaEstadistica(View view){
        setContentView(R.layout.estadistica);
        tlEstadisticas = findViewById(R.id.tlEstadisticas);
        SQLite con = new SQLite(this);
        SQLiteDatabase baseDatos = con.getWritableDatabase();
        View registro = LayoutInflater.from(this).inflate(R.layout.item_table_layout_pn2, null, false);
        TextView tvAVGPro = registro.findViewById(R.id.tvAVGPro);
        TextView tvMaxPro = registro.findViewById(R.id.tvMaxPro);
        TextView tvMinPro = registro.findViewById(R.id.tvMinPro);
        TextView tvAVGPe = registro.findViewById(R.id.tvAVGPe);
        TextView tvMaxPe = registro.findViewById(R.id.tvMaxPe);
        TextView tvMinPe = registro.findViewById(R.id.tvMinPe);

        Cursor avgPro = baseDatos.rawQuery("select avg(precio) from productos", null);
        avgPro.moveToFirst();
        tvAVGPro.setText(avgPro.getString(0));
        Cursor maxPro = baseDatos.rawQuery("select max(precio) from productos", null);
        maxPro.moveToFirst();
        tvMaxPro.setText(maxPro.getString(0));
        Cursor minPro = baseDatos.rawQuery("select min(precio) from productos", null);
        minPro.moveToFirst();
        tvMinPro.setText(minPro.getString(0));
        Cursor avgPe = baseDatos.rawQuery("select avg(importe) from pedidos", null);
        avgPe.moveToFirst();
        tvAVGPe.setText(avgPe.getString(0));
        Cursor maxPe = baseDatos.rawQuery("select max(importe) from pedidos", null);
        maxPe.moveToFirst();
        tvMaxPe.setText(maxPe.getString(0));
        Cursor minPe = baseDatos.rawQuery("select min(importe) from pedidos", null);
        minPe.moveToFirst();
        tvMinPe.setText(minPe.getString(0));


        tlEstadisticas.addView(registro);
    }*/

/*
    public void insertar(View view) {

        SQLite con = new SQLite(this);
        SQLiteDatabase baseDatos = con.getWritableDatabase();
        String codigo = txtCodigo.getText().toString();
        String descripcion = txtDescripcion.getText().toString();
        String precio = txtPrecio.getText().toString();
        String tipoProducto = spEnumProducto.toString();




        if (codigo.isEmpty() == false && descripcion.isEmpty() == false && precio.isEmpty() == false && tipoProducto.isEmpty() == false) {
            ContentValues registro = new ContentValues();
            registro.put("codigo", codigo);
            registro.put("descripcion", descripcion);
            registro.put("precio", precio);
            registro.put("tipoProducto", tipoProducto);
            baseDatos.insert("productos", null, registro);
            txtCodigo.setText("");
            txtDescripcion.setText("");
            txtPrecio.setText("");

            Toast.makeText(this, "Se insertado exitosamente", Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(this, "Los campos deben tener texto", Toast.LENGTH_LONG).show();
        }
        baseDatos.close();
        llenarTabla();
    }*/


    /*
    public void eliminar(View view) {
        SQLite con = new SQLite(this);
        SQLiteDatabase baseDatos = con.getWritableDatabase();
        String sql = String.format ("select codigo from productos where unidades=%s", txtUnidades.getText().toString());
        SQLite con1 = new SQLite(this);
        SQLiteDatabase baseDatos2 = con1.getWritableDatabase();
        Cursor fila3 = baseDatos2.rawQuery(sql, null);
        fila3.moveToPosition(fila3.getPosition()+1);
        String codigo=fila3.getString(0);
        //String codigo = txtCodigo.getText().toString();
        if (codigo.isEmpty() == false) {
            int cant = baseDatos.delete("productos", "codigo="+codigo+"", null);
            if (cant > 0) {
                Toast.makeText(this, "El producto fue eliminado", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "El producto no se encontro", Toast.LENGTH_LONG).show();
            }
            txtUnidades.setText("");
            txtDescripcion.setText("");
            txtPrecio.setText("");
        } else {
            Toast.makeText(this, "El campo codigo debe tener texto", Toast.LENGTH_LONG).show();
        }
        vistaEditar(view);
    }



    public void editar(View view) {
        SQLite con = new SQLite(this);
        SQLiteDatabase baseDatos = con.getWritableDatabase();
        //String codigo = txtCodigo.getText().toString();
        String descripcion = txtDescripcion.getText().toString();
        String precio = txtPrecio.getText().toString();
        String tipoProducto = txtTipoProducto.getText().toString();
        String unidades = txtUnidades.getText().toString();
        String sql = String.format ("select codigo from productos where unidades=%s", unidades);
        SQLite con1 = new SQLite(this);
        SQLiteDatabase baseDatos2 = con1.getWritableDatabase();
        Cursor fila3 = baseDatos2.rawQuery(sql, null);
        Cursor fila4 = baseDatos2.rawQuery(sql, null);
        fila3.moveToPosition(fila3.getPosition()+1);
        String codigo = "";
        if (fila3.getCount()==0){
            String sql2 = String.format ("select codigo from productos where descripcion LIKE '%%%s%%'",descripcion);
            SQLite con2 = new SQLite(this);
            SQLiteDatabase baseDatos3 = con2.getWritableDatabase();
            fila4 = baseDatos3.rawQuery(sql2, null);
            fila4.moveToPosition(fila4.getPosition()+1);
            codigo =fila4.getString(0);
        }else{
            codigo=fila3.getString(0);
        }


        if (!unidades.isEmpty() && !descripcion.isEmpty() && !precio.isEmpty()) {
            //String codigo=fila3.getString(0);
            ContentValues registro = new ContentValues();
            registro.put("codigo", codigo);
            registro.put("unidades", unidades);
            registro.put("descripcion", descripcion);
            registro.put("precio", precio);
            registro.put("tipoProducto", tipoProducto);
            //Toast.makeText(this, "unidades="+unidades, Toast.LENGTH_LONG).show();


            int cant = baseDatos.update("productos", registro, "codigo="+codigo+"",null);

            if (cant > 0) {
                Toast.makeText(this, "El registro se a editado exitosamente", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "El registro no fue encontrado", Toast.LENGTH_LONG).show();
            }
        } else {
            Toast.makeText(this, "Los campos no deben estar vacios", Toast.LENGTH_LONG).show();
        }

        llenarTabla();
    }
    */
    /*
    public void editar2(View view) {
        SQLite con = new SQLite(this);
        SQLiteDatabase baseDatos = con.getWritableDatabase();
        String numPedido = txtNumPedido.getText().toString();
        String descripcion = txtDescripcion.getText().toString();
        String fecha = txtDate.getText().toString();
        String precio = txtPrecio.getText().toString();


        if (!descripcion.isEmpty() && !numPedido.isEmpty() && !precio.isEmpty()&& !fecha.isEmpty()) {
            ContentValues registro = new ContentValues();
            registro.put("descripcion", descripcion);
            registro.put("numPedido", numPedido);
            registro.put("importe", precio);
            registro.put("fecha", fecha);


            int cant = baseDatos.update("pedidos", registro, "numPedido="+numPedido+"",null);

            if (cant > 0) {
                Toast.makeText(this, "El registro se a editado exitosamente", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "El registro no fue encontrado", Toast.LENGTH_LONG).show();
            }
        } else {
            Toast.makeText(this, "Los campos no deben estar vacios", Toast.LENGTH_LONG).show();
        }

        llenarTabla2();
    }


    public void eliminar2(View view) {
        SQLite con = new SQLite(this);
        SQLiteDatabase baseDatos = con.getWritableDatabase();
        String numPedido = txtNumPedido.getText().toString();
        if (numPedido.isEmpty() == false) {
            int cant = baseDatos.delete("pedidos", "numPedido="+numPedido+"", null);
            if (cant > 0) {
                Toast.makeText(this, "El pedido fue eliminado", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "El pedido no se encontro", Toast.LENGTH_LONG).show();
            }
            txtNumPedido.setText("");
            txtDescripcion.setText("");
            txtPrecio.setText("");
            txtDate.setText("");
        } else {
            Toast.makeText(this, "El campo numero de pedido debe tener texto", Toast.LENGTH_LONG).show();
        }
        vistaEditarPedido(view);
    }*/

    /*
    public void llenarTabla() {

        tlProductos.removeAllViews();
        SQLite con = new SQLite(this);
        SQLiteDatabase baseDatos = con.getWritableDatabase();
        String buscarPor = txtBuscarPor.getText().toString();
        String listaBuscarPor = spBuscarPor.getSelectedItem().toString();
        String sql = "";


        if (!buscarPor.isEmpty()) {
            if (listaBuscarPor == "Unidades") {
                sql = String.format ("select unidades,descripcion,precio,tipoProducto from productos where unidades=%s", buscarPor);
            } else if (listaBuscarPor == "Descripcion") {//DUDA AQUI
                //sql = String.format ("descripcion LIKE %%%s%%",buscarPor);

                //sql = String.format ("select codigo,descripcion,precio,tipoProducto from productos where descripcion LIKE "+"%"+buscarPor+"%");
                //Toast.makeText(this, sql+"    sale esto", Toast.LENGTH_SHORT).show();
                sql = String.format ("select unidades,descripcion,precio,tipoProducto from productos where descripcion LIKE '%%%s%%'",buscarPor);

                //sql = String.format ("select codigo,descripcion,precio,tipoProducto from productos where descripcion LIKE %s%",buscarPor);
            } else if (listaBuscarPor == "Precio") {
                sql = String.format ("select unidades,descripcion,precio,tipoProducto from productos where precio=%s", buscarPor);
            } else if (listaBuscarPor == "TipoProducto") {
                sql = String.format ("select unidades,descripcion,precio,tipoProducto from productos where tipoProducto=%s", buscarPor);
            } else {
                sql = "select unidades,descripcion,precio,tipoProducto from productos";
            }
        } else {
            sql = "select unidades,descripcion,precio,tipoProducto from productos";

        }
        Cursor fila = baseDatos.rawQuery(sql , null);
        fila.moveToFirst();
        do {

                View registro = LayoutInflater.from(this).inflate(R.layout.item_table_layout_pn, null, false);
                TextView tvUnidades = registro.findViewById(R.id.tvDescripcion2);
                TextView tvDescripcion = registro.findViewById(R.id.tvDescripcion);
                TextView tvPrecio = registro.findViewById(R.id.tvPrecio);
                TextView tvTipoProducto = registro.findViewById(R.id.tvTipoProducto);
                //if(fila.getString(0).length()>0) {
                    tvUnidades.setText(fila.getString(0));
                    tvDescripcion.setText(fila.getString(1));
                    tvPrecio.setText(fila.getString(2));
                    tvTipoProducto.setText(fila.getString(3));
                    tlProductos.addView(registro);
                //}

        } while (fila.moveToNext());

    }



    public void clickRegistroProducto(View view){
        resetColorRegistros();
        view.setBackgroundColor(Color.GRAY);
        TableRow registro= (TableRow) view;
        txtTipoProducto = findViewById(R.id.txtTipoProducto);
        txtUnidades=findViewById(R.id.txtUnidades);
        TextView controlCodigo= (TextView) registro.getChildAt(0);
        String unidades=controlCodigo.getText().toString();
        String sql = String.format ("select codigo from productos where unidades=%s", unidades);
        SQLite con = new SQLite(this);
        SQLiteDatabase baseDatos = con.getWritableDatabase();
        Cursor fila = baseDatos.rawQuery(sql, null);
        fila.moveToPosition(fila.getPosition()+1);
        String codigo=fila.getString(0);
        //Toast.makeText(this, "primero:"+codigo, Toast.LENGTH_SHORT).show();


        if(!unidades.isEmpty()) {
            //String sql2 = String.format ("select unidades,descripcion,precio,tipoProducto from productos where codigo=%s", codigo);
            String sql2 = String.format ("select unidades,descripcion,precio,tipoProducto from productos where unidades=%s", unidades);

            Cursor fila2 = baseDatos.rawQuery(sql2, null);

            fila2.moveToPosition(fila2.getPosition()+1);


                txtUnidades.setText(fila2.getString(0));
                txtDescripcion.setText(fila2.getString(1));
                txtPrecio.setText(fila2.getString(2));
                txtTipoProducto.setText(fila2.getString(3));

            } else {
                txtUnidades.setText("");
                txtDescripcion.setText("");
                txtPrecio.setText("");
                txtTipoProducto.setText("");
                Toast.makeText(this, "No se ha encontrado ningun registro", Toast.LENGTH_SHORT).show();
            }

    }
    */

    /*public void resetColorRegistros(){

        for (int i=0;i<tlProductos.getChildCount();i++){
            View registros = tlProductos.getChildAt(i);
            registros.setBackgroundColor(Color.WHITE);
        }

    }*//*
    public void resetColorRegistros2(){

        for (int i=0;i<tlPedidos.getChildCount();i++){
            View registros = tlPedidos.getChildAt(i);
            registros.setBackgroundColor(Color.WHITE);
        }

    }

    /*public void clickBotonBuscar(View view){
        llenarTabla();

    }*/
    /*
    public void clickBotonBuscar2(View view){
        llenarTabla2();

    }

    private void llenarTabla2() {
        tlPedidos.removeAllViews();
        SQLite con = new SQLite(this);
        SQLiteDatabase baseDatos = con.getWritableDatabase();
        String buscarPor = txtBuscarPor.getText().toString();

        String listaBuscarPor = spBuscarPor.getSelectedItem().toString();
        String sql = "";



        if (!buscarPor.isEmpty()) {
            if (listaBuscarPor == "descripcion") {
                //sql = String.format("select numPedido,descripcion,fecha from pedidos inner join productos where pedidos.codigo=" + buscarPor + " and productos.codigo=" + buscarPor + "");
                String sql2 = String.format ("select codigo from productos where descripcion LIKE '%%%s%%'",buscarPor);
                Cursor fila2 = baseDatos.rawQuery(sql2, null);
                fila2.moveToPosition(fila2.getPosition()+1);
                sql = String.format("select numPedido,codigo,unidades,fecha from pedidos where codigo=%s",fila2.getString(0));
            }else if (listaBuscarPor == "fecha") {
                sql = String.format ("select numPedido,codigo,unidades,fecha from pedidos where fecha LIKE '%%%s%%'", buscarPor);
                //} else if (listaBuscarPor == "Fecha") {
             //   sql = String.format ("select numPedido,codigo,fecha from pedidos where fecha=%s", buscarPor);

            } else {
                sql = "select numpedido,codigo,unidades,fecha from pedidos";
            }
        } else {
            sql = "select numPedido,codigo,unidades,fecha from pedidos";

        }
        Cursor fila = baseDatos.rawQuery(sql, null);
        fila.moveToFirst();
        do {

            View registro = LayoutInflater.from(this).inflate(R.layout.item_table_layout_pn3, null, false);
            TextView tvnumPedido = registro.findViewById(R.id.tvnumPedido);
            TextView tvdescripcion = registro.findViewById(R.id.tvDescripcion2);
            String sql2 = String.format ("select descripcion from productos where codigo=%s", fila.getString(1));
            Cursor fila2 = baseDatos.rawQuery(sql2, null);
            fila2.moveToPosition(fila2.getPosition()+1);
            TextView tvunidades = registro.findViewById(R.id.tvUnidades2);
            TextView tvfecha = registro.findViewById(R.id.tvFecha);
            tvnumPedido.setText(fila.getString(0));
            tvdescripcion.setText(fila2.getString(0));
            tvunidades.setText(fila.getString(2));
            tvfecha.setText(fila.getString(3));
            tlPedidos.addView(registro);

        } while (fila.moveToNext());
    }
    public void clickRegistroProducto2(View view){
        resetColorRegistros2();
        view.setBackgroundColor(Color.GRAY);
        TableRow registro= (TableRow) view;

        TextView controlnumPedido= (TextView) registro.getChildAt(0);
        String numPedido=controlnumPedido.getText().toString();
        SQLite con = new SQLite(this);
        SQLiteDatabase baseDatos = con.getWritableDatabase();
        if(!numPedido.isEmpty()) {
            String sql = String.format ("select unidades,codigo,fecha,importe from pedidos where numPedido=%s", numPedido);
            Cursor fila = baseDatos.rawQuery(sql, null);
            fila.moveToPosition(fila.getPosition()+1);

            String sql2 = String.format ("select descripcion from productos where codigo=%s", fila.getString(1));
            Cursor fila2 = baseDatos.rawQuery(sql2, null);
            fila2.moveToPosition(fila2.getPosition()+1);

            txtNumPedido.setText(fila.getString(0));
            txtDescripcion.setText(fila2.getString(0));
            txtDate.setText(fila.getString(2));
            txtPrecio.setText(fila.getString(3));
        } else {
            txtNumPedido.setText("");
            txtCodigo.setText("");
            txtDate.setText("");
            txtPrecio.setText("");
            Toast.makeText(this, "No se ha encontrado ningun registro", Toast.LENGTH_SHORT).show();
        }

    }

        */


}








































