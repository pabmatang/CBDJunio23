package com.example.basededatossqlite;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;


import androidx.appcompat.app.AppCompatActivity;

import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    EditText txtCodigo;
    EditText txtNumPedido;
    EditText txtDate;
    EditText txtDescripcion;
    EditText txtPrecio;
    EditText txtBuscarPor;
    TableLayout tlProductos;
    Spinner spBuscarPor;
    TableLayout tlEstadisticas;
    TableLayout tlPedidos;
    Spinner spEnumProducto;
    EditText txtTipoProducto;






    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //super.onCreate(savedInstanceState);
        setContentView(R.layout.portada);

    }

    public void vistaEditar(View view){
        setContentView(R.layout.activity_main);

        txtCodigo = findViewById(R.id.txtCodigo);
        txtDescripcion = findViewById(R.id.txtDescripcion);
        txtPrecio = findViewById(R.id.txtPrecio);
        tlProductos = findViewById(R.id.tlProductos);
        txtBuscarPor = findViewById(R.id.txtBuscarPor);
        spBuscarPor = findViewById(R.id.spBuscarPor);
        List<String> listaCampos = Arrays.asList("SelecScione el campo a buscar", "Codigo", "Descripcion", "Precio","Tipo de Producto");
        ArrayAdapter<String> adaptador = new ArrayAdapter(this, android.R.layout.simple_spinner_item, listaCampos);
        spBuscarPor.setAdapter(adaptador);
        llenarTabla();

    }

    public void vistaCrearProducto(View view) {
        setContentView(R.layout.crearproducto);
        txtCodigo = findViewById(R.id.codigo);
        txtDescripcion = findViewById(R.id.descripcion);
        txtPrecio = findViewById(R.id.precio);

        spEnumProducto = findViewById(R.id.spinner2);


        List<String> tiposdeproducto = Arrays.asList("AGUA","REFRESCOS","BEBIDAS_ALCOHOLICAS","HIGIENE","FRUTOS_SECOS","CONGELADOS","FRUTA","VERDURA","LACTEOS","CERNES","PESCADOS","HUEVOS","DULCES");
        ArrayAdapter<String> adaptador = new ArrayAdapter(this, android.R.layout.simple_spinner_item, tiposdeproducto);
        spEnumProducto.setAdapter(adaptador);


    }
    public void vistaInsertarProducto(View view){
            SQLite con = new SQLite(this);
            SQLiteDatabase baseDatos = con.getWritableDatabase();
            String codigo = txtCodigo.getText().toString();
            String descripcion = txtDescripcion.getText().toString();
            String precio = txtPrecio.getText().toString();

            //spEnumProducto = findViewById(R.id.spinner2);

            String tipoProducto = spEnumProducto.getSelectedItem().toString();
            txtTipoProducto = findViewById(R.id.txtTipoProducto);
            Cursor codigoMinActual = baseDatos.rawQuery("select count(codigo) from productos",null);
            codigoMinActual.moveToPosition(codigoMinActual.getPosition()+1);
            Integer codigoMinActual2=codigoMinActual.getInt(0);


        if (codigo.isEmpty() == false && descripcion.isEmpty() == false && precio.isEmpty() == false && tipoProducto.isEmpty() == false) {

            if(Integer.parseInt(codigo)<=codigoMinActual2){
                Toast.makeText(this, "Elegir un codigo mayor, ese esta en uso", Toast.LENGTH_LONG).show();

            }else{

                ContentValues registro = new ContentValues();
                registro.put("codigo", codigo);
                registro.put("descripcion", descripcion);
                registro.put("precio", precio);
                registro.put("tipoProducto", tipoProducto);
                baseDatos.insert("productos", null, registro);
                txtCodigo.setText("");
                txtDescripcion.setText("");
                txtPrecio.setText("");
                //txtTipoProducto.setText("");
                Toast.makeText(this, "Se insertado exitosamente", Toast.LENGTH_LONG).show();

                }

        } else {

                Toast.makeText(this, "Los campos deben tener texto", Toast.LENGTH_LONG).show();
            }
            baseDatos.close();



    }
    public void vistaVolver(View view){
        setContentView(R.layout.portada);
    }

    public void vistaCrearPedido(View view){
        setContentView(R.layout.crearpedido);
        txtNumPedido = findViewById(R.id.numPedido);
        txtCodigo = findViewById(R.id.codigo2);
        txtPrecio = findViewById(R.id.precio2);
        txtDate = findViewById(R.id.fecha);

    }

    public void vistaInsertarPedido(View view){
        SQLite con = new SQLite(this);
        SQLiteDatabase baseDatos = con.getWritableDatabase();
        String codigo = txtCodigo.getText().toString();
        String numPedido = txtNumPedido.getText().toString();
        String precio = txtPrecio.getText().toString();
        String fecha = txtDate.getText().toString();
        Cursor numPedidoMinActual = baseDatos.rawQuery("select count(numPedido) from pedidos",null);
        numPedidoMinActual.moveToPosition(numPedidoMinActual.getPosition()+1);
        Integer numPedidoMinActual2=numPedidoMinActual.getInt(0);


        if (codigo.isEmpty() == false && numPedido.isEmpty() == false && precio.isEmpty() == false && fecha.isEmpty() == false) {
            if(Integer.parseInt(numPedido)<=numPedidoMinActual2) {
                Toast.makeText(this, "Elegir un numero de pedido mayor, ese esta en uso", Toast.LENGTH_LONG).show();
            }else{
            ContentValues registro = new ContentValues();
            registro.put("codigo", codigo);
            registro.put("numPedido", numPedido);
            registro.put("importe", precio);
            registro.put("fecha", fecha);
            baseDatos.insert("pedidos", null, registro);
            txtCodigo.setText("");
            txtNumPedido.setText("");
            txtPrecio.setText("");
            txtDate.setText("");
            Toast.makeText(this, "Se insertado exitosamente", Toast.LENGTH_LONG).show();}
        } else {

            Toast.makeText(this, "Los campos deben tener texto", Toast.LENGTH_LONG).show();
        }
        baseDatos.close();

    }
    public void vistaEditarPedido(View view){
        setContentView(R.layout.activity_main2);

        txtCodigo = findViewById(R.id.codigo3);
        txtNumPedido = findViewById(R.id.numPedido2);
        txtPrecio = findViewById(R.id.precio3);
        txtDate = findViewById(R.id.fecha2);
        tlPedidos = findViewById(R.id.tlPedidos);
        txtBuscarPor = findViewById(R.id.txtBuscarPor);
        spBuscarPor = findViewById(R.id.spBuscarPor);
        List<String> listaCampos = Arrays.asList("Seleccione el campo a buscar","codigo");
        ArrayAdapter<String> adaptador = new ArrayAdapter(this, android.R.layout.simple_spinner_item, listaCampos);
        spBuscarPor.setAdapter(adaptador);
        llenarTabla2();

    }

    public void vistaEstadistica(View view){
        setContentView(R.layout.estadistica);
        tlEstadisticas = findViewById(R.id.tlEstadisticas);
        SQLite con = new SQLite(this);
        SQLiteDatabase baseDatos = con.getWritableDatabase();
        View registro = LayoutInflater.from(this).inflate(R.layout.item_table_layout_pn2, null, false);
        TextView tvAVGPro = registro.findViewById(R.id.tvAVGPro);
        TextView tvMaxPro = registro.findViewById(R.id.tvMaxPro);
        TextView tvMinPro = registro.findViewById(R.id.tvMinPro);
        TextView tvAVGPe = registro.findViewById(R.id.tvAVGPe);
        TextView tvMaxPe = registro.findViewById(R.id.tvMaxPe);
        TextView tvMinPe = registro.findViewById(R.id.tvMinPe);

        Cursor avgPro = baseDatos.rawQuery("select avg(precio) from productos", null);
        avgPro.moveToFirst();
        tvAVGPro.setText(avgPro.getString(0));
        Cursor maxPro = baseDatos.rawQuery("select max(precio) from productos", null);
        maxPro.moveToFirst();
        tvMaxPro.setText(maxPro.getString(0));
        Cursor minPro = baseDatos.rawQuery("select min(precio) from productos", null);
        minPro.moveToFirst();
        tvMinPro.setText(minPro.getString(0));
        Cursor avgPe = baseDatos.rawQuery("select avg(importe) from pedidos", null);
        avgPe.moveToFirst();
        tvAVGPe.setText(avgPe.getString(0));
        Cursor maxPe = baseDatos.rawQuery("select max(importe) from pedidos", null);
        maxPe.moveToFirst();
        tvMaxPe.setText(maxPe.getString(0));
        Cursor minPe = baseDatos.rawQuery("select min(importe) from pedidos", null);
        minPe.moveToFirst();
        tvMinPe.setText(minPe.getString(0));


        tlEstadisticas.addView(registro);
    }


    public void insertar(View view) {

        SQLite con = new SQLite(this);
        SQLiteDatabase baseDatos = con.getWritableDatabase();
        String codigo = txtCodigo.getText().toString();
        String descripcion = txtDescripcion.getText().toString();
        String precio = txtPrecio.getText().toString();
        String tipoProducto = spEnumProducto.toString();

        Toast.makeText(this, tipoProducto+"tipoProductoooooooooooooooooo", Toast.LENGTH_LONG).show();



        if (codigo.isEmpty() == false && descripcion.isEmpty() == false && precio.isEmpty() == false && tipoProducto.isEmpty() == false) {
            ContentValues registro = new ContentValues();
            registro.put("codigo", codigo);
            registro.put("descripcion", descripcion);
            registro.put("precio", precio);
            registro.put("tipoProducto", tipoProducto);
            baseDatos.insert("productos", null, registro);
            txtCodigo.setText("");
            txtDescripcion.setText("");
            txtPrecio.setText("");

            Toast.makeText(this, "Se insertado exitosamente", Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(this, "Los campos deben tener texto", Toast.LENGTH_LONG).show();
        }
        baseDatos.close();
        llenarTabla();
    }

    public void eliminar(View view) {
        SQLite con = new SQLite(this);
        SQLiteDatabase baseDatos = con.getWritableDatabase();
        String codigo = txtCodigo.getText().toString();
        if (codigo.isEmpty() == false) {
            int cant = baseDatos.delete("productos", "codigo="+codigo+"", null);
            if (cant > 0) {
                Toast.makeText(this, "El producto fue eliminado", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "El producto no se encontro", Toast.LENGTH_LONG).show();
            }
            txtCodigo.setText("");
            txtDescripcion.setText("");
            txtPrecio.setText("");
        } else {
            Toast.makeText(this, "El campo codigo debe tener texto", Toast.LENGTH_LONG).show();
        }
        vistaEditar(view);
    }

    public void editar(View view) {
        SQLite con = new SQLite(this);
        SQLiteDatabase baseDatos = con.getWritableDatabase();
        String codigo = txtCodigo.getText().toString();
        String descripcion = txtDescripcion.getText().toString();
        String precio = txtPrecio.getText().toString();
        String tipoProducto = txtTipoProducto.getText().toString();

        if (!codigo.isEmpty() && !descripcion.isEmpty() && !precio.isEmpty()) {
            ContentValues registro = new ContentValues();
            registro.put("codigo", codigo);
            registro.put("descripcion", descripcion);
            registro.put("precio", precio);
            registro.put("tipoProducto", tipoProducto);


            int cant = baseDatos.update("productos", registro, "codigo="+codigo+"",null);

            if (cant > 0) {
                Toast.makeText(this, "El registro se a editado exitosamente", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "El registro no fue encontrado", Toast.LENGTH_LONG).show();
            }
        } else {
            Toast.makeText(this, "Los campos no deben estar vacios", Toast.LENGTH_LONG).show();
        }

        llenarTabla();
    }
    public void editar2(View view) {
        SQLite con = new SQLite(this);
        SQLiteDatabase baseDatos = con.getWritableDatabase();
        String numPedido = txtNumPedido.getText().toString();
        String codigo = txtCodigo.getText().toString();
        String fecha = txtDate.getText().toString();
        String precio = txtPrecio.getText().toString();

        if (!codigo.isEmpty() && !numPedido.isEmpty() && !precio.isEmpty()&& !fecha.isEmpty()) {
            ContentValues registro = new ContentValues();
            registro.put("codigo", codigo);
            registro.put("numPedido", numPedido);
            registro.put("importe", precio);
            registro.put("fecha", fecha);


            int cant = baseDatos.update("pedidos", registro, "numPedido="+numPedido+"",null);

            if (cant > 0) {
                Toast.makeText(this, "El registro se a editado exitosamente", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "El registro no fue encontrado", Toast.LENGTH_LONG).show();
            }
        } else {
            Toast.makeText(this, "Los campos no deben estar vacios", Toast.LENGTH_LONG).show();
        }

        llenarTabla2();
    }
    public void eliminar2(View view) {
        SQLite con = new SQLite(this);
        SQLiteDatabase baseDatos = con.getWritableDatabase();
        String numPedido = txtNumPedido.getText().toString();
        if (numPedido.isEmpty() == false) {
            int cant = baseDatos.delete("pedidos", "numPedido="+numPedido+"", null);
            if (cant > 0) {
                Toast.makeText(this, "El pedido fue eliminado", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "El pedido no se encontro", Toast.LENGTH_LONG).show();
            }
            txtNumPedido.setText("");
            txtCodigo.setText("");
            txtPrecio.setText("");
            txtDate.setText("");
        } else {
            Toast.makeText(this, "El campo numero de pedido debe tener texto", Toast.LENGTH_LONG).show();
        }
        vistaEditarPedido(view);
    }


    public void llenarTabla() {

        tlProductos.removeAllViews();
        SQLite con = new SQLite(this);
        SQLiteDatabase baseDatos = con.getWritableDatabase();
        String buscarPor = txtBuscarPor.getText().toString();
        String listaBuscarPor = spBuscarPor.getSelectedItem().toString();
        String sql = "";


        if (!buscarPor.isEmpty()) {
            if (listaBuscarPor == "Codigo") {
                sql = String.format ("select codigo,descripcion,precio,tipoProducto from productos where codigo=%s", buscarPor);
            } else if (listaBuscarPor == "Descripcion") {
                sql = String.format ("select codigo,descripcion,precio,tipoProducto from productos where descripcion LIKE %s%",buscarPor);
            } else if (listaBuscarPor == "Precio") {
                sql = String.format ("select codigo,descripcion,precio,tipoProducto from productos where precio=%s", buscarPor);
            } else if (listaBuscarPor == "TipoProducto") {
                sql = String.format ("select codigo,descripcion,precio,tipoProducto from productos where tipoProducto=%s", buscarPor);
            } else {
                sql = "select codigo,descripcion,precio,tipoProducto from productos";
            }
        } else {
            sql = "select codigo,descripcion,precio,tipoProducto from productos";

        }
        Cursor fila = baseDatos.rawQuery(sql, null);
        fila.moveToFirst();
        do {

                View registro = LayoutInflater.from(this).inflate(R.layout.item_table_layout_pn, null, false);
                TextView tvCodigo = registro.findViewById(R.id.tvCodigo);
                TextView tvDescripcion = registro.findViewById(R.id.tvDescripcion);
                TextView tvPrecio = registro.findViewById(R.id.tvPrecio);
                TextView tvTipoProducto = registro.findViewById(R.id.tvTipoProducto);
                tvCodigo.setText(fila.getString(0));
                tvDescripcion.setText(fila.getString(1));
                tvPrecio.setText(fila.getString(2));
                tvTipoProducto.setText(fila.getString(3));
                tlProductos.addView(registro);

        } while (fila.moveToNext());

    }

    public void clickRegistroProducto(View view){
        resetColorRegistros();
        view.setBackgroundColor(Color.GRAY);
        TableRow registro= (TableRow) view;
        txtTipoProducto = findViewById(R.id.txtTipoProducto);

        TextView controlCodigo= (TextView) registro.getChildAt(0);
        String codigo=controlCodigo.getText().toString();
        SQLite con = new SQLite(this);
        SQLiteDatabase baseDatos = con.getWritableDatabase();
        if(!codigo.isEmpty()) {
            String sql = String.format ("select codigo,descripcion,precio,tipoProducto from productos where codigo=%s", codigo);
            Cursor fila = baseDatos.rawQuery(sql, null);

            fila.moveToPosition(fila.getPosition()+1);

            txtCodigo.setText(fila.getString(0));
                txtDescripcion.setText(fila.getString(1));
                txtPrecio.setText(fila.getString(2));
                txtTipoProducto.setText(fila.getString(3));

            } else {
                txtCodigo.setText("");
                txtDescripcion.setText("");
                txtPrecio.setText("");
                txtTipoProducto.setText("");
                Toast.makeText(this, "No se ha encontrado ningun registro", Toast.LENGTH_SHORT).show();
            }

    }


    public void resetColorRegistros(){

        for (int i=0;i<tlProductos.getChildCount();i++){
            View registros = tlProductos.getChildAt(i);
            registros.setBackgroundColor(Color.WHITE);
        }

    }
    public void resetColorRegistros2(){

        for (int i=0;i<tlPedidos.getChildCount();i++){
            View registros = tlPedidos.getChildAt(i);
            registros.setBackgroundColor(Color.WHITE);
        }

    }
    public void clickBotonBuscar(View view){
        llenarTabla();

    }
    public void clickBotonBuscar2(View view){
        llenarTabla2();

    }

    private void llenarTabla2() {
        tlPedidos.removeAllViews();
        SQLite con = new SQLite(this);
        SQLiteDatabase baseDatos = con.getWritableDatabase();
        String buscarPor = txtBuscarPor.getText().toString();

        String listaBuscarPor = spBuscarPor.getSelectedItem().toString();
        String sql = "";
        //Toast.makeText(this, baseDatos.rawQuery("select count(codigo) from productos")+" Mirar aqui", Toast.LENGTH_SHORT).show();



        if (!buscarPor.isEmpty()) {
            if (listaBuscarPor == "codigo") {
                sql = String.format ("select numPedido,descripcion,fecha from pedidos inner join productos where pedidos.codigo="+buscarPor+" and productos.codigo="+buscarPor+"");
                //sql = String.format("select numPedido,descripcion,fecha from pedidos inner join productos on pedidos.codigo=1 and productos.codigo=1 ");
                //} else if (listaBuscarPor == "Descripcion") {
                //sql = String.format ("select numPedido,codigo,fecha from pedidos where descripcion LIKE %s%", buscarPor);
                //} else if (listaBuscarPor == "Fecha") {
             //   sql = String.format ("select numPedido,codigo,fecha from pedidos where fecha=%s", buscarPor);

            } else {
                sql = "select numpedido,codigo,fecha from pedidos";
            }
        } else {
            sql = "select numPedido,codigo,fecha from pedidos";

        }
        Cursor fila = baseDatos.rawQuery(sql, null);
        fila.moveToFirst();
        do {

            View registro = LayoutInflater.from(this).inflate(R.layout.item_table_layout_pn3, null, false);
            TextView tvnumPedido = registro.findViewById(R.id.tvnumPedido);
            TextView tvCodigo = registro.findViewById(R.id.tvCodigo);
            TextView tvfecha = registro.findViewById(R.id.tvFecha);
            tvnumPedido.setText(fila.getString(0));
            tvCodigo.setText(fila.getString(1));
            tvfecha.setText(fila.getString(2));
            tlPedidos.addView(registro);

        } while (fila.moveToNext());
    }
    public void clickRegistroProducto2(View view){
        resetColorRegistros2();
        view.setBackgroundColor(Color.GRAY);
        TableRow registro= (TableRow) view;

        TextView controlnumPedido= (TextView) registro.getChildAt(0);
        String numPedido=controlnumPedido.getText().toString();
        SQLite con = new SQLite(this);
        SQLiteDatabase baseDatos = con.getWritableDatabase();
        if(!numPedido.isEmpty()) {
            String sql = String.format ("select numPedido,codigo,fecha,importe from pedidos where numPedido=%s", numPedido);
            Cursor fila = baseDatos.rawQuery(sql, null);

            fila.moveToPosition(fila.getPosition()+1);
            txtNumPedido.setText(fila.getString(0));
            txtCodigo.setText(fila.getString(1));
            txtDate.setText(fila.getString(2));
            txtPrecio.setText(fila.getString(3));
        } else {
            txtNumPedido.setText("");
            txtCodigo.setText("");
            txtDate.setText("");
            txtPrecio.setText("");
            Toast.makeText(this, "No se ha encontrado ningun registro", Toast.LENGTH_SHORT).show();
        }

    }

    //public void enum tipoProducto {
       // agua,refrescos,bebidasAlcoholicas,higiene,frutosSecos,congelados,fruta,verdura,lacteos,carnes,pescados,
   // }
    public enum tipodeProducto {
        AGUA,REFRESCOS,BEBIDAS_ALCOHOLICAS,HIGIENE,FRUTOS_SECOS,CONGELADOS,FRUTA,VERDURA,LACTEOS,CERNES,PESCADOS,HUEVOS

    }
}








































